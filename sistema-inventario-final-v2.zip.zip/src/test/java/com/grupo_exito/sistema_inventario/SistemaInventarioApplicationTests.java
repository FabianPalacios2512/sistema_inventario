package com.grupo_exito.sistema_inventario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaInventarioApplicationTests {

	@Test
	void contextLoads() {
	}

}
